"""One-step acquisition on an explicitly supplied Gaussian posterior."""
import numpy as np
from scipy.special import ndtr, roots_hermitenorm
from .models import vector


def validate_posterior(mean, covariance, noise, cost):
    mean, noise, cost = (vector(v, n) for v, n in
                         [(mean, "mean"), (noise, "noise"), (cost, "cost")])
    covariance = np.asarray(covariance, dtype=float)
    n = len(mean)
    if covariance.shape != (n, n) or len(noise) != n or len(cost) != n:
        raise ValueError("Posterior dimensions do not align")
    if not np.all(np.isfinite(covariance)) or not np.allclose(covariance, covariance.T):
        raise ValueError("Covariance must be finite and symmetric")
    if n and np.linalg.eigvalsh(covariance).min() < -1e-8:
        raise ValueError("Covariance must be positive semidefinite")
    if np.any(noise <= 0) or np.any(cost <= 0):
        raise ValueError("Candidate observation noise and cost must be positive")
    return mean, covariance, noise, cost


def integrated_variance_reduction(mean, covariance, noise, cost, weights=None):
    """Expected latent squared-error reduction per cost, over a fixed query grid."""
    mean, covariance, noise, cost = validate_posterior(mean, covariance, noise, cost)
    n = len(mean)
    if n == 0:
        raise ValueError("At least one candidate required")
    weights = np.full(n, 1/n) if weights is None else vector(weights, "weights")
    if len(weights) != n or np.any(weights < 0) or not np.isclose(weights.sum(), 1):
        raise ValueError("Query weights must form a probability vector")
    return (weights @ covariance ** 2) / (np.diag(covariance) + noise) / cost


def threshold_probability(mean, variance, threshold):
    """Probability latent response is below threshold (e.g., reduced albumin)."""
    mean, variance = np.asarray(mean), np.maximum(np.asarray(variance), 0)
    result = np.zeros(np.broadcast_shapes(mean.shape, variance.shape))
    np.divide(threshold - mean, np.sqrt(variance), out=result, where=variance > 0)
    return np.where(variance > 0, ndtr(result), (mean < threshold).astype(float))


def decision_voi(mean, covariance, noise, cost, threshold=50.0,
                 false_positive=1.0, false_negative=1.0, nodes=96):
    """Gauss-Hermite approximation of expected reduction in grid-average Bayes risk.

    Fixed hyperparameters and Gaussian observation model are required. Compare
    quadrature orders before acting; small negative estimates are returned, not
    silently clipped. This is model-based value, not empirical assay benefit.
    """
    mean, covariance, noise, cost = validate_posterior(mean, covariance, noise, cost)
    if not len(mean) or nodes < 2 or not np.all(np.isfinite([threshold, false_positive, false_negative])):
        raise ValueError("Invalid decision specification")
    if min(false_positive, false_negative) <= 0:
        raise ValueError("Decision costs must be positive")
    def risk(mu, var):
        p = threshold_probability(mu, var, threshold)
        return np.minimum(false_negative * p, false_positive * (1-p))
    diagonal = np.maximum(np.diag(covariance), 0)
    current = risk(mean, diagonal).mean()
    z, weights = roots_hermitenorm(nodes)
    weights = weights / np.sqrt(2*np.pi)
    values = []
    for j in range(len(mean)):
        total = diagonal[j] + noise[j]
        conditional_mean = mean[None, :] + z[:, None] * covariance[:, j] / np.sqrt(total)
        conditional_variance = np.maximum(diagonal - covariance[:, j] ** 2 / total, 0)
        expected = weights @ risk(conditional_mean, conditional_variance).mean(axis=1)
        values.append((current - expected) / cost[j])
    return np.array(values)
